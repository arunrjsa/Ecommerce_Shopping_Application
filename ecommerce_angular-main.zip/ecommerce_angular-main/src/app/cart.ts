export class Cart {

    productId!: string;
    userId!: string;
    name!: string;
    price!: string;
    quantity!: string;
    description!: string;
    imageUrl!: string;
    subTotal!: string;
        
}
