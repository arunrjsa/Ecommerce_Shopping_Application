export class Admin {

    adminId!: string;
    password!: string;

}
