export class User {
    userId!:string;
    password!:string;
    phone!:string;
    name!: string;
    cpassword!:string;
}
